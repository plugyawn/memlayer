#!/usr/bin/env bash
set -euo pipefail
cd /root/wr-track3-locom-20260606
. /root/venv_track3/bin/activate
export PYTHONUNBUFFERED=1
export MODE=pair
export TRACK3_PROJ_SPEC_LOG_DIR=/root/prime_track3_locom_proj_specificity_logs_retry
export TRACK3_RESUME_CHECKPOINT=/root/.cache/track3_checkpoints/track3_cd500red_softmerge_pr2872000_p110_ckpt1600_seed3710_step1600.pt
export TRACK3_TRAIN_STEPS=2000
export TRACK3_PREFIX_ACTIVE_END=1800
export TRACK3_LOCOM_SAMPLE_TOKENS=1024
export TRACK3_LOCOM_STEPS=5
export TRACK3_LOCOM_INNER_LR=2e-4
bash tools/run_track3_locom_proj_specificity.sh
