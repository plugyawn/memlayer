# Track 3 Prefix Specificity Manifest

| lane | enabled | local_opt | random | mode | alpha | norm_target | min_cos_desc | intent |
| --- | ---: | --- | ---: | --- | ---: | ---: | ---: | --- |
| active_k5 | 1 | sgd | 0 | normal | 1.0 | 0.00 | 0.0 | natural true-post c_fc LocoProp K5 |
| noloco | 1 | sgd | 0 | normal | 0.0 | 0.00 | 0.0 | same harness with alpha-zero no-parameter-correction control |
| random_norm002 | 1 | random | 1 | normal | 1.0 | 0.02 | 0.0 | same-shape random perturbation at 2% base-step norm |
| orthogonal_k5_norm002 | 1 | sgd | 0 | orthogonal | 1.0 | 0.02 | -1.0 | true-post correction with descent-parallel component removed at 2% base-step norm |

Common invariants:

- `train_steps=2000`
- `layers=all`
- `steps=5`
- `sample_tokens=1024`
- `target_space=post`
- `true_post_grad=True`
- `require_loss_decrease=True`
- `inner_lr=0.0002`
- `prox=0.1`
- `norm_to_base=False`
- `norm_cap=0.2`
- `active_windows=0:1800`
- `end_step=1800`
- `target_loss=3.28`
- `seed_base=0`
- `seed_offset=3710`
- `cooldown_frac=1.0`
- `lr_schedule=power`
- `lr_power=2.0`
- `lr_schedule_steps=3000`
- `lr_min_eta=0.0`
- `lr_bump_windows=`
- `lr_switch_step=-1`
- `lr_after_switch=`
- `resume_load_optimizers=True`
