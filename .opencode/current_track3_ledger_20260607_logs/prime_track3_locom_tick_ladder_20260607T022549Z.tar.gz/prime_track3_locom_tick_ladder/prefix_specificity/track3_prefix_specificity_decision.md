# Track 3 LocoProp-M Prefix Specificity Decision

Control lane: `noloco` from `/root/prime_track3_locom_tick_ladder/prefix_specificity/track3_prefix_noloco_seed3710.log`

## Validation Table

| lane | category | 1600 | 1625 | 1650 | 1675 | 1700 | 1725 | 1750 | 1775 | 1800 | 1900 | 2000 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| active_k5 | active | 3.48242 | 3.45137 | 3.43561 | 3.42615 | 3.41884 | 3.41287 | 3.40794 | 3.40358 | 3.39872 | 3.38478 | 3.37337 |
| noloco | control | 3.48242 | 3.45137 | 3.43563 | 3.42615 | 3.41882 | 3.41288 | 3.40795 | 3.40362 | 3.39873 | 3.38478 | 3.37338 |

## Gain Vs No-Loco

| lane | category | 1600 | 1625 | 1650 | 1675 | 1700 | 1725 | 1750 | 1775 | 1800 | 1900 | 2000 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| active_k5 | active | +0.00000 | +0.00000 | +0.00002 | +0.00000 | -0.00002 | +0.00001 | +0.00001 | +0.00004 | +0.00001 | +0.00000 | +0.00001 |

## Slope Table

| lane | category | 1600->1700 drop/100 | 1700->1800 drop/100 | 1800->1900 drop/100 | 1900->2000 drop/100 |
| --- | --- | ---: | ---: | ---: | ---: |
| active_k5 | active | 0.06358 | 0.02012 | 0.01394 | 0.01141 |
| noloco | control | 0.06360 | 0.02009 | 0.01395 | 0.01140 |

## Apply-Scale Summary

| lane | category | 1600 | 1625 | 1650 | 1675 | 1700 | 1725 | 1750 | 1775 | 1800 | 1900 | 2000 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| active_k5 | active | 0.0071 | 0.0055 | 0.0066 | 0.0053 | 0.0065 | 0.0102 | 0.0083 | 0.0061 | nan | nan | nan |
| noloco | control | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | nan | nan | nan |

## Decision

Best active LocoProp gain @ 2000: +0.00001 via `active_k5`.
Best random/orthogonal/parallel gain @ 2000: nan.

Known active-prefix reproduction check @ 2000: expected 3.37334, actual 3.37337, delta +0.00003.

Read: active, random, and orthogonal do not materially beat no-Loco; prefix gain is probably schedule/checkpoint state, not LocoProp.
