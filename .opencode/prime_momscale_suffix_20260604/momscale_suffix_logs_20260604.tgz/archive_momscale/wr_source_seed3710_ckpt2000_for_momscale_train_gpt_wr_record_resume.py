"""
contra-muon-to-soft-muon.py

This file descends from the [NanoGPT speedrun](https://github.com/KellerJordan/modded-nanogpt).
It was prepared as a simplified version of the speedrun for use in neural net optimization research.

---

Contra-Muon-to-Soft-Muon.

Start with contra-muon for diversity/exploration, interpolate through standard muon to soft-muon for exploitation
https://web.archive.org/web/20260505070142/https://nilin.github.io/contra-muon-and-soft-muon/

---

This submission incorporates features from the following previous submissions

@kumarkrishna PR274 / Skylight-001
  NorMuon-lite row/column variance normalization
  u/w floor postprocessing
  lr=0.0375 style Muon setup

@nilin (me): PR275 / Contra-Muon
  Introduces Contra-Muon update term

@samacqua: PR278 / MLP SOAP preconditioning 
  SOAP preconditioning machinery / MLP SOAP idea.
  Our script uses that SOAP machinery and extends the selected SOAP set to MLP+V.

@yash-oai: PR287 / power law LR schedule
  Power-law LR schedule PowerCool:
  min(flat_lr, c * (t_end - step)^1.2)
  PR287-style cooldown constants / schedule tuning.

The SOAP-like preconditioning from samacqua / PR 278 is also applied to the attention value-projection (V) matrices in this submission.
"""

import os
import sys
with open(sys.argv[0]) as f:
    code = f.read() # read the code of this file ASAP, for logging
import argparse
import uuid
import time
from pathlib import Path

import torch
from torch import Tensor, nn
from torch.optim import AdamW
import torch.nn.functional as F
import torch.distributed as dist

def _wr_resume_flag(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).lower() in {"1", "true", "yes", "on"}

WR_RESUME_CHECKPOINT = os.environ.get("WR_RESUME_CHECKPOINT", "").strip()
WR_RESUME_MODEL_CHECKPOINT = os.environ.get("WR_RESUME_MODEL_CHECKPOINT", "").strip()
WR_RESUME_OPTIMIZER_CHECKPOINT = os.environ.get("WR_RESUME_OPTIMIZER_CHECKPOINT", "").strip()
WR_RESUME_ADVANCE_DATA = _wr_resume_flag("WR_RESUME_ADVANCE_DATA", "1")
WR_RESUME_RESTORE_RNG = _wr_resume_flag("WR_RESUME_RESTORE_RNG", "1")
WR_RESUME_LOAD_ADAM = _wr_resume_flag("WR_RESUME_LOAD_ADAM", "0")
WR_RESUME_LOAD_OPTIMIZERS = _wr_resume_flag("WR_RESUME_LOAD_OPTIMIZERS", "0")
WR_RESUME_STRICT_MODEL = _wr_resume_flag("WR_RESUME_STRICT_MODEL", "1")
WR_RESUME_LOG_MODEL_DIFF = _wr_resume_flag("WR_RESUME_LOG_MODEL_DIFF", "1")
WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE = float(os.environ.get("WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE", "1.0"))
WR_RESUME_OPTIMIZER2_SOAP_RESET = _wr_resume_flag("WR_RESUME_OPTIMIZER2_SOAP_RESET", "0")
WR_RESUME_OPTIMIZER2_NOR_RESET = _wr_resume_flag("WR_RESUME_OPTIMIZER2_NOR_RESET", "0")
WR_SAVE_CHECKPOINT = os.environ.get("WR_SAVE_CHECKPOINT", "").strip()
WR_SAVE_CHECKPOINT_STEP = int(os.environ.get("WR_SAVE_CHECKPOINT_STEP") or "-1")
WR_SAVE_CHECKPOINT_STEPS = {
    int(x)
    for x in os.environ.get("WR_SAVE_CHECKPOINT_STEPS", "").split(",")
    if x.strip()
}
WR_TARGET_LOSS = float(os.environ.get("WR_TARGET_LOSS", "0.0"))

def _wr_load_checkpoint(path: str) -> dict:
    return torch.load(path, map_location=device)

def _wr_checkpoint_step(checkpoint: dict) -> int:
    return int(checkpoint["step"])

def _wr_restore_rng_from_checkpoint(checkpoint: dict) -> None:
    if "rng_cpu" in checkpoint:
        torch.set_rng_state(checkpoint["rng_cpu"].detach().cpu().to(torch.uint8))
    if "rng_cuda" in checkpoint:
        states = [state.detach().cpu().to(torch.uint8) for state in checkpoint["rng_cuda"]]
        if len(states) == torch.cuda.device_count():
            torch.cuda.set_rng_state_all(states)
        elif len(states) == 1:
            torch.cuda.set_rng_state(states[0], device=device)
        else:
            print0(
                f"wr_resume_rng_cuda_skip saved_states={len(states)} local_cuda_devices={torch.cuda.device_count()}",
                console=True,
            )

def _wr_model_diff(model: nn.Module, model_state: dict) -> None:
    if not WR_RESUME_LOG_MODEL_DIFF:
        return
    current_keys = set(model.state_dict().keys())
    saved_keys = set(model_state.keys())
    missing = sorted(current_keys - saved_keys)
    extra = sorted(saved_keys - current_keys)
    print0(
        f"wr_resume_model_key_diff missing={len(missing)} extra={len(extra)} "
        f"missing_head={missing[:6]} extra_head={extra[:6]}",
        console=True,
    )

def _wr_set_optimizer2_step(optimizer2: torch.optim.Optimizer, step: int) -> None:
    if hasattr(optimizer2, "step_count"):
        optimizer2.step_count = step

def _wr_adjust_optimizer2_resume_state(optimizer2: torch.optim.Optimizer) -> None:
    scaled_momentum = 0
    reset_soap = 0
    reset_nor = 0
    for state in optimizer2.state.values():
        momentum = state.get("momentum")
        if torch.is_tensor(momentum) and WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE != 1.0:
            momentum.mul_(WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE)
            scaled_momentum += 1
        if WR_RESUME_OPTIMIZER2_SOAP_RESET and "row_gg" in state:
            for key in ("exp_avg_sq", "row_gg", "col_gg"):
                value = state.get(key)
                if torch.is_tensor(value):
                    value.zero_()
            state["q_row"] = None
            state["q_col"] = None
            state["soap_step"] = 0
            reset_soap += 1
        if WR_RESUME_OPTIMIZER2_NOR_RESET and "second_moment" in state:
            value = state.get("second_moment")
            if torch.is_tensor(value):
                value.zero_()
                reset_nor += 1
    if (
        WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE != 1.0
        or WR_RESUME_OPTIMIZER2_SOAP_RESET
        or WR_RESUME_OPTIMIZER2_NOR_RESET
    ):
        print0(
            f"wr_resume_optimizer2_adjust momentum_scale:{WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE} "
            f"scaled_momentum:{scaled_momentum} soap_reset:{reset_soap} nor_reset:{reset_nor}",
            console=True,
        )

def _wr_checkpoint_save_path(path: str, step: int) -> str:
    if "{step}" in path:
        return path.format(step=step)
    if WR_SAVE_CHECKPOINT_STEPS and len(WR_SAVE_CHECKPOINT_STEPS) > 1:
        base, suffix = os.path.splitext(path)
        return f"{base}_step{step}{suffix or '.pt'}"
    return path

def maybe_save_wr_checkpoint(
    path: str,
    step: int,
    model: nn.Module,
    optimizer1: torch.optim.Optimizer,
    optimizer2: torch.optim.Optimizer,
    *,
    val_loss=None,
) -> None:
    if not path:
        return
    if WR_SAVE_CHECKPOINT_STEPS:
        if step not in WR_SAVE_CHECKPOINT_STEPS:
            return
    elif WR_SAVE_CHECKPOINT_STEP >= 0 and step != WR_SAVE_CHECKPOINT_STEP:
        return
    save_path = _wr_checkpoint_save_path(path, step)
    checkpoint = {
        "step": int(step),
        "seed": int(os.environ.get("WR_SEED", "0")),
        "train_steps": int(FINAL_TRAIN_STEPS),
        "schedule_steps": int(FINAL_SCHEDULE_STEPS),
        "val_loss": None if val_loss is None else float(val_loss),
        "model": {k: v.detach().cpu() for k, v in model.state_dict().items()},
        "optimizers": [optimizer1.state_dict(), optimizer2.state_dict()],
        "rng_cpu": torch.get_rng_state().detach().cpu(),
        "rng_cuda": [s.detach().cpu() for s in torch.cuda.get_rng_state_all()],
    }
    torch.save(checkpoint, save_path)
    print0(f"wr_save_checkpoint path:{save_path} step:{step} val_loss:{checkpoint['val_loss']}", console=True)

@torch.no_grad()
def maybe_load_wr_resume_checkpoint(
    model: nn.Module,
    optimizer1: torch.optim.Optimizer,
    optimizer2: torch.optim.Optimizer,
) -> int:
    model_checkpoint_path = WR_RESUME_MODEL_CHECKPOINT or WR_RESUME_CHECKPOINT
    optimizer_checkpoint_path = WR_RESUME_OPTIMIZER_CHECKPOINT or WR_RESUME_CHECKPOINT
    if not model_checkpoint_path and not optimizer_checkpoint_path:
        return 0
    optimizer_checkpoint = _wr_load_checkpoint(optimizer_checkpoint_path) if optimizer_checkpoint_path else None
    model_checkpoint = (
        optimizer_checkpoint
        if model_checkpoint_path == optimizer_checkpoint_path
        else _wr_load_checkpoint(model_checkpoint_path)
    )
    checkpoint_for_step = model_checkpoint or optimizer_checkpoint
    if optimizer_checkpoint is not None and WR_RESUME_LOAD_OPTIMIZERS:
        saved_optimizers = optimizer_checkpoint.get("optimizers", [])
        if len(saved_optimizers) < 2:
            raise ValueError("WR_RESUME_LOAD_OPTIMIZERS=1 requires two optimizer state dicts")
        optimizer1.load_state_dict(saved_optimizers[0])
        optimizer2.load_state_dict(saved_optimizers[1])
        _wr_adjust_optimizer2_resume_state(optimizer2)
    model_state = model_checkpoint["model"]
    _wr_model_diff(model, model_state)
    model.load_state_dict(model_state, strict=WR_RESUME_STRICT_MODEL)
    if WR_RESUME_LOAD_ADAM:
        adam_checkpoint = optimizer_checkpoint or model_checkpoint
        saved_optimizers = adam_checkpoint.get("optimizers", [])
        if not saved_optimizers:
            raise ValueError("WR_RESUME_LOAD_ADAM=1 but checkpoint has no optimizer state")
        optimizer1.load_state_dict(saved_optimizers[0])
        # The loaded state dict can overwrite group metadata. Restore WR lr
        # constants while preserving Adam moments.
        for group, initial_lr in zip(optimizer1.param_groups, (0.3, 1 / 320, 0.01)):
            group["initial_lr"] = initial_lr
            group["lr"] = initial_lr
        optimizer1.param_groups[0]["power_c"] = ADAM_EMBED_POWER_C
        optimizer1.param_groups[1]["power_c"] = ADAM_PROJ_POWER_C
        optimizer1.param_groups[2]["power_c"] = ADAM_OTHER_POWER_C
    if WR_RESUME_RESTORE_RNG:
        _wr_restore_rng_from_checkpoint(model_checkpoint)
    step = _wr_checkpoint_step(checkpoint_for_step)
    _wr_set_optimizer2_step(optimizer2, step)
    print0(
        f"wr_resume_loaded model_path:{model_checkpoint_path or '<none>'} "
        f"optimizer_path:{optimizer_checkpoint_path or '<none>'} step:{step} "
        f"model_seed:{model_checkpoint.get('seed')} optimizer_seed:{optimizer_checkpoint.get('seed') if optimizer_checkpoint else None} "
        f"model_val_loss:{model_checkpoint.get('val_loss')} "
        f"load_adam:{WR_RESUME_LOAD_ADAM} load_optimizers:{WR_RESUME_LOAD_OPTIMIZERS} "
        f"restore_rng:{WR_RESUME_RESTORE_RNG} optimizer2_step_count:{getattr(optimizer2, 'step_count', '<none>')} "
        f"optimizer2_momentum_scale:{WR_RESUME_OPTIMIZER2_MOMENTUM_SCALE} "
        f"optimizer2_soap_reset:{WR_RESUME_OPTIMIZER2_SOAP_RESET} "
        f"optimizer2_nor_reset:{WR_RESUME_OPTIMIZER2_NOR_RESET}",
        console=True,
    )
    return step


# cuDNN SDPA can fail to build an execution plan for this compiled causal-attention
# layout on some PyTorch/CUDA/cuDNN combinations. Leave Flash/mem-efficient/math SDPA
# enabled and only remove the cuDNN backend from consideration.
torch.backends.cuda.enable_cudnn_sdp(False)

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=0)
args = parser.parse_args()

SEED = args.seed
# Hardcoded final schedule constants
FINAL_TRAIN_STEPS = int(os.environ.get("FINAL_TRAIN_STEPS", "2000"))
FINAL_SCHEDULE_STEPS = int(os.environ.get("FINAL_SCHEDULE_STEPS", "3105"))
FINAL_LR_POWER = 1.2
ADAM_EMBED_POWER_C = 4.976805410800738e-05
ADAM_PROJ_POWER_C = 5.184172302917436e-07
ADAM_OTHER_POWER_C = 1.6589351369335795e-06
MUON_POWER_C = 3.3169534699576625e-06
FINAL_MUON_WD = 0.025
EXPERIMENT_NAME = "contra-muon-to-soft-muon"
EXPERIMENT_INTUITION = "Interpolate Muon update from Contra Muon to normal Muon, then from normal Muon to p=0.1 soft Muon."
CONTRA_MUON_COEFF = -0.2
SOFT_MUON_P = 0.1
SOFT_MUON_SCALE = "none"
SOFT_MUON_INPUT_NORM = "frobenius_schatten4"
SOFT_MUON_CEIL = 0.80
CONTRA_HOLD_END_STEP = 0
CONTRA_TO_NORMAL_END_STEP = 2000
NORMAL_TO_SOFT_START_STEP = 2500
NORMAL_TO_SOFT_END_STEP = 3010
MU = 0.95
MUON_LR = 0.0375
MUON_WEIGHT_DECAY = FINAL_MUON_WD
TARGET_UW = 0.3825
SOAP_TARGET_UW = TARGET_UW
NONSOAP_TARGET_UW = TARGET_UW
NOR_BETA2 = 0.95
SOAP_BETA2 = 0.90
SOAP_PRECONDITION_FREQUENCY = 10
SOAP_DENOM_POWER = 0.50
SOAP_BLEND = 1.00
SOAP_UPDATE_BEFORE_USE = False
SOAP_PARAM_MODE = "mlp_plus_v"
ATTN_SOAP_DENOM_FLOOR = 0.55
ATTN_SOAP_BLEND = 1.00
V_SOAP_BLEND = 0.95
V_SOAP_BLEND_RAMP_END_STEP = 0
ATTN_EARLY_TRUST_FLOOR = 0.45
ATTN_EARLY_TRUST_CAP = 0.85
ATTN_TRUST_FLOOR_END_STEP = 1375
ATTN_TRUST_FLOOR_FADE_END_STEP = 1625
ATTN_TRUST_MIN_AGREE = 0.20
ATTN_TRUST_MIN_GRAD_ALIGN = 0.00
ATTN_TRUST_POWER = 1.00
ATTN_SOAP_FADE_START_STEP = 1000000000
ATTN_SOAP_FADE_END_STEP = 1000000000
NO_CONTRA_PARAM = ""
NO_SOFTMUON_PARAM = ""
TRAIN_PROGRESS_INTERVAL = 0
LOG_DIR = Path("experiment-logs/all-runs/2026-05-09/validation-ceil-0.8")


########################################
#              Dataloader              #
########################################

def _load_data_shard(file: Path):
    header = torch.from_file(str(file), False, 256, dtype=torch.int32) # header is 256 int32
    assert header[0] == 20240520, "magic number mismatch in the data .bin file"
    assert header[1] == 1, "unsupported version"
    num_tokens = int(header[2]) # number of tokens (claimed)
    with file.open("rb", buffering=0) as f:
        tokens = torch.empty(num_tokens, dtype=torch.uint16, pin_memory=True)
        f.seek(256 * 4)
        nbytes = f.readinto(tokens.numpy()) # avoid bytes->array copy
        assert nbytes == 2 * num_tokens, "number of tokens read does not match header"
    return tokens

def distributed_data_generator(filename_pattern: str, batch_size: int, seq_len=1024):
    world_size = dist.get_world_size()
    rank = dist.get_rank()
    files = sorted(Path.cwd().glob(filename_pattern))
    assert batch_size % world_size == 0
    local_batch_size = batch_size // world_size
    file_iter = iter(files)
    tokens, pos = _load_data_shard(next(file_iter)), 0
    while True:
        if pos + batch_size + 1 >= len(tokens):
            tokens, pos = _load_data_shard(next(file_iter)), 0
        buf = tokens[pos + rank * local_batch_size:][:local_batch_size + 1]
        inputs = buf[:-1].to(device="cuda", dtype=torch.int32, non_blocking=True)
        targets = buf[1:].to(device="cuda", dtype=torch.int64, non_blocking=True)
        pos += batch_size
        yield inputs.view(-1, seq_len), targets.view(-1, seq_len)


########################################
#             Architecture             #
########################################

def norm(x: Tensor):
    return F.rms_norm(x, (x.size(-1),))

class RMSNorm(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gains = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        return (norm(x.float()) * self.gains).type_as(x)

class Linear(nn.Linear):
    def __init__(self, in_features, out_features):
        super().__init__(in_features, out_features, bias=True)

    def forward(self, x):
        return F.linear(x, self.weight.type_as(x), self.bias.type_as(x))

class Rotary(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        # half-truncate RoPE (w/ base freq tuning)
        angular_freq = (1 / 1024) ** torch.linspace(0, 1, steps=dim//4, dtype=torch.float32)
        self.register_buffer("angular_freq", torch.cat([angular_freq, angular_freq.new_zeros(dim//4)]))

    def forward(self, x_BTHD: Tensor):
        pos = torch.arange(x_BTHD.size(1), dtype=torch.float32, device=x_BTHD.device)
        theta = torch.outer(pos, self.angular_freq)[None, :, None, :]
        cos, sin = theta.cos(), theta.sin()
        x1, x2 = x_BTHD.to(dtype=torch.float32).chunk(2, dim=-1)
        y1 = x1 * cos + x2 * sin
        y2 = x1 * (-sin) + x2 * cos
        return torch.cat((y1, y2), 3).type_as(x_BTHD)

class CausalSelfAttention(nn.Module):
    def __init__(self, dim: int, head_dim=128):
        super().__init__()
        self.num_heads = dim // head_dim
        self.head_dim = head_dim
        hdim = self.num_heads * self.head_dim
        self.q = Linear(dim, hdim)
        self.k = Linear(dim, hdim)
        self.v = Linear(dim, hdim)
        self.proj = Linear(hdim, dim)
        self.rotary = Rotary(head_dim)

    def forward(self, x: Tensor):
        B, T = x.size(0), x.size(1)
        q = self.q(x).view(B, T, self.num_heads, self.head_dim)
        k = self.k(x).view(B, T, self.num_heads, self.head_dim)
        v = self.v(x).view(B, T, self.num_heads, self.head_dim)
        q, k = norm(q), norm(k)
        q, k = self.rotary(q), self.rotary(k)
        y = F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2),
                                           v.transpose(1, 2), scale=0.12, is_causal=True).transpose(1, 2)
        y = y.contiguous().view(B, T, self.num_heads * self.head_dim)
        y = self.proj(y)
        return y

class MLP(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        hdim = 4 * dim
        self.fc = Linear(dim, hdim)
        self.proj = Linear(hdim, dim)

    def forward(self, x: Tensor):
        x = self.fc(x)
        x = x.relu().square()
        x = self.proj(x)
        return x

class Block(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.attn = CausalSelfAttention(dim)
        self.mlp = MLP(dim)
        self.norm1 = RMSNorm(dim)
        self.norm2 = RMSNorm(dim)

    def forward(self, x: Tensor):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x

class GPT(nn.Module):
    def __init__(self, vocab_size: int, num_layers: int, model_dim: int):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, model_dim).bfloat16()
        self.blocks = nn.ModuleList([Block(model_dim) for _ in range(num_layers)])
        self.proj = Linear(model_dim, vocab_size)
        self.norm1 = RMSNorm(model_dim)
        self.norm2 = RMSNorm(model_dim)

    def forward(self, inputs: Tensor, targets: Tensor):
        x = self.norm1(self.embed(inputs))
        for block in self.blocks:
            x = block(x)
        logits = self.proj(self.norm2(x)).float()
        logits = 15 * logits * (logits.square() + 15**2).rsqrt()
        return F.cross_entropy(logits.view(targets.numel(), -1), targets.view(-1), reduction="sum")


########################################
#              Optimizer               #
########################################

def gram_frobenius_norm_estimate(G: Tensor, keepdim: bool = False, eps: float = 1e-10) -> Tensor:
    X = G.float()
    gram = X.mT @ X if X.size(-2) > X.size(-1) else X @ X.mT
    return gram.norm(dim=(-2, -1), keepdim=keepdim).sqrt().clamp_min(eps)

def zeropower_via_newtonschulz5(G: Tensor) -> Tensor:
    assert G.ndim >= 2
    X = G.bfloat16()
    if G.size(-2) > G.size(-1):
        X = X.mT

    # Use the Gram-Frobenius estimate sqrt(||X X^T||_F) instead of direct
    # Frobenius norm or power iteration.
    X = X / gram_frobenius_norm_estimate(X, keepdim=True, eps=1e-7).to(X.dtype)
    # Perform the NS iterations, not optimizing for wallclock speed
    a, b, c = 2, -1.5, 0.5
    for _ in range(12):
        A = X @ X.mT
        B = b * A + c * A @ A
        X = a * X + B @ X

    if G.size(-2) > G.size(-1):
        X = X.mT
    return X

def _soft_coefficients(p: float) -> tuple[float, tuple[float, ...]]:
    if p == 0.0:
        return 1.0, (0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    if p == 0.1:
        return 0.0, (0.1091613623, 0.07085664498, 0.05210528973, 0.05457295795, 0.05011334061, 0.03334622198, 0.05022104481, 0.1053727358, 0.1187323776, 0.1185061091, 0.1185059576, 0.1185059576)
    raise ValueError(f"unsupported soft-muon singular-value power: {p}")

def zeropower_frobenius_norm_like(G: Tensor) -> float:
    return (G.numel() / max(G.size(-2), G.size(-1)))**0.5

def soft_via_newtonschulz5(G: Tensor, p: float, scale_mode: str, input_norm: str) -> Tensor:
    assert G.ndim >= 2
    X = G.bfloat16()
    if G.size(-2) > G.size(-1):
        X = X.mT

    if input_norm == "frobenius_schatten4":
        X = X / gram_frobenius_norm_estimate(X, keepdim=True, eps=1e-7).to(X.dtype)
    elif input_norm != "frobenius":
        raise ValueError(f"unsupported soft_muon input_norm: {input_norm}")
    else:
        X = X / gram_frobenius_norm_estimate(X, keepdim=True, eps=1e-7).to(X.dtype)
    constant, coeffs = _soft_coefficients(p)

    a, b, c = 2, -1.5, 0.5
    basis = [X]
    for _ in range(len(coeffs)):
        A = X @ X.mT
        B = b * A + c * A @ A
        X = a * X + B @ X
        basis.append(X)

    out = constant * basis[-1]
    for coeff, basis_term in zip(coeffs, basis[:-1]):
        out = out + coeff * basis_term

    value_at_one = constant + sum(coeffs)
    if scale_mode == "top":
        out = out / value_at_one
    elif scale_mode == "top_sqrt":
        out = out / value_at_one**0.5
    elif scale_mode == "frobenius":
        theoretical_opower_norm = zeropower_frobenius_norm_like(out)
        out = out * theoretical_opower_norm / gram_frobenius_norm_estimate(out)
    elif scale_mode == "frobenius_sqrt":
        theoretical_opower_norm = zeropower_frobenius_norm_like(out)
        out = out * (theoretical_opower_norm / gram_frobenius_norm_estimate(out))**0.5
    elif scale_mode != "none":
        raise ValueError(f"unsupported soft_muon scale: {scale_mode}")

    if G.size(-2) > G.size(-1):
        out = out.mT
    return out

def scale_to_unit_operator_norm(G: Tensor, eps: float = 1e-10) -> Tensor:
    return G / gram_frobenius_norm_estimate(G, eps=eps).to(G.dtype)

def should_soap_param(name: str) -> bool:
    is_mlp_fc = name.endswith(".mlp.fc.weight")
    is_mlp_proj = name.endswith(".mlp.proj.weight")
    is_attn_proj = name.endswith(".attn.proj.weight")
    is_qkv = (
        name.endswith(".attn.q.weight")
        or name.endswith(".attn.k.weight")
        or name.endswith(".attn.v.weight")
    )
    is_q = name.endswith(".attn.q.weight")
    is_k = name.endswith(".attn.k.weight")
    is_v = name.endswith(".attn.v.weight")
    if SOAP_PARAM_MODE == "mlp_all":
        return is_mlp_fc or is_mlp_proj
    if SOAP_PARAM_MODE == "mlp_fc":
        return is_mlp_fc
    if SOAP_PARAM_MODE == "mlp_proj":
        return is_mlp_proj
    if SOAP_PARAM_MODE == "mlp_plus_attn_proj":
        return is_mlp_fc or is_mlp_proj or is_attn_proj
    if SOAP_PARAM_MODE == "mlp_plus_q":
        return is_mlp_fc or is_mlp_proj or is_q
    if SOAP_PARAM_MODE == "mlp_plus_k":
        return is_mlp_fc or is_mlp_proj or is_k
    if SOAP_PARAM_MODE == "mlp_plus_v":
        return is_mlp_fc or is_mlp_proj or is_v
    if SOAP_PARAM_MODE == "mlp_plus_qkv":
        return is_mlp_fc or is_mlp_proj or is_qkv
    if SOAP_PARAM_MODE == "all_hidden":
        return is_mlp_fc or is_mlp_proj or is_attn_proj or is_qkv
    raise ValueError(f"unknown SOAP_PARAM_MODE={SOAP_PARAM_MODE}")

def is_attn_proj_param(name: str) -> bool:
    return name.endswith(".attn.proj.weight")

def is_attn_param(name: str) -> bool:
    return (
        name.endswith(".attn.q.weight")
        or name.endswith(".attn.k.weight")
        or name.endswith(".attn.v.weight")
        or name.endswith(".attn.proj.weight")
    )

def is_v_param(name: str) -> bool:
    return name.endswith(".attn.v.weight")

def param_matches_spec(name: str, spec: str) -> bool:
    keys = {part.strip() for part in spec.split(",") if part.strip()}
    return (
        ("q" in keys and name.endswith(".attn.q.weight"))
        or ("k" in keys and name.endswith(".attn.k.weight"))
        or ("v" in keys and name.endswith(".attn.v.weight"))
        or ("attn_proj" in keys and name.endswith(".attn.proj.weight"))
    )

def tensor_cosine(a: Tensor, b: Tensor, eps: float = 1e-8) -> Tensor:
    a_f, b_f = a.float(), b.float()
    return (a_f * b_f).sum() / (a_f.norm() * b_f.norm()).clamp_min(eps)

def trust_gate(raw: Tensor, soap: Tensor, grad: Tensor, eps: float = 1e-8) -> Tensor:
    # SOAP is trusted when it still points with raw momentum and is at least as
    # gradient-aligned as raw momentum. This catches stale whitening bases.
    raw_grad = tensor_cosine(raw, grad, eps)
    soap_grad = tensor_cosine(soap, grad, eps)
    soap_raw = tensor_cosine(soap, raw, eps)

    agree_gate = ((soap_raw - ATTN_TRUST_MIN_AGREE) / (1 - ATTN_TRUST_MIN_AGREE)).clamp(0, 1)
    denom = (raw_grad - ATTN_TRUST_MIN_GRAD_ALIGN).clamp_min(eps)
    grad_gate = ((soap_grad - ATTN_TRUST_MIN_GRAD_ALIGN) / denom).clamp(0, 1)
    gate = (agree_gate * grad_gate).clamp(0, 1)
    if ATTN_TRUST_POWER != 1.0:
        gate = gate.pow(ATTN_TRUST_POWER)
    return gate

def early_trust_floor_for_step(step: int) -> float:
    if ATTN_TRUST_FLOOR_FADE_END_STEP <= ATTN_TRUST_FLOOR_END_STEP:
        return 0.0 if step >= ATTN_TRUST_FLOOR_FADE_END_STEP else ATTN_EARLY_TRUST_FLOOR
    if step < ATTN_TRUST_FLOOR_END_STEP:
        return ATTN_EARLY_TRUST_FLOOR
    if step >= ATTN_TRUST_FLOOR_FADE_END_STEP:
        return 0.0
    return ATTN_EARLY_TRUST_FLOOR * (
        ATTN_TRUST_FLOOR_FADE_END_STEP - step
    ) / (ATTN_TRUST_FLOOR_FADE_END_STEP - ATTN_TRUST_FLOOR_END_STEP)

def bounded_trust_gate(gate: Tensor, step: int) -> Tensor:
    floor = early_trust_floor_for_step(step)
    cap = ATTN_EARLY_TRUST_CAP if step < ATTN_TRUST_FLOOR_FADE_END_STEP else 1.0
    return gate.clamp(min=floor, max=cap)

def attention_soap_blend_for_step(step: int) -> float:
    if step < ATTN_SOAP_FADE_START_STEP:
        return 1.0
    if step >= ATTN_SOAP_FADE_END_STEP:
        return 0.0
    if ATTN_SOAP_FADE_END_STEP <= ATTN_SOAP_FADE_START_STEP:
        return 0.0
    return (
        ATTN_SOAP_FADE_END_STEP - step
    ) / (ATTN_SOAP_FADE_END_STEP - ATTN_SOAP_FADE_START_STEP)

def norm_preserving_blend(raw: Tensor, soap: Tensor, gate: Tensor, eps: float = 1e-8) -> Tensor:
    blended = raw + (soap - raw) * gate.to(raw.dtype)
    raw_norm = gram_frobenius_norm_estimate(raw, eps=eps)
    blended_norm = gram_frobenius_norm_estimate(blended, eps=eps)
    return (blended * (raw_norm / blended_norm).to(blended.dtype)).to(raw.dtype)

def soap_eigenbasis(mat: Tensor) -> Tensor:
    try:
        _, q = torch.linalg.eigh(mat + 1e-30 * torch.eye(mat.size(0), device=mat.device))
    except RuntimeError:
        _, q = torch.linalg.eigh(mat.double() + 1e-30 * torch.eye(mat.size(0), device=mat.device))
        q = q.float()
    return torch.flip(q, [1])

def soap_basis_qr(row_gg, col_gg, q_row, q_col, exp_avg_sq):
    row_eig = torch.diag(q_row.T @ row_gg @ q_row)
    row_sort = torch.argsort(row_eig, descending=True)
    q_row = q_row[:, row_sort]
    exp_avg_sq = exp_avg_sq.index_select(0, row_sort)
    q_row, _ = torch.linalg.qr(row_gg @ q_row)

    col_eig = torch.diag(q_col.T @ col_gg @ q_col)
    col_sort = torch.argsort(col_eig, descending=True)
    q_col = q_col[:, col_sort]
    exp_avg_sq = exp_avg_sq.index_select(1, col_sort)
    q_col, _ = torch.linalg.qr(col_gg @ q_col)
    return q_row, q_col, exp_avg_sq

def soap_precondition_momentum(update, state, beta2=SOAP_BETA2, eps=1e-8,
                               blend=SOAP_BLEND, denom_floor_ratio=0.0):
    update_f = update.float()
    if state["q_row"] is None:
        return update
    q_row, q_col = state["q_row"], state["q_col"]
    projected = q_row.T @ update_f @ q_col
    state["exp_avg_sq"].mul_(beta2).add_(projected.square(), alpha=1 - beta2)
    denom = state["exp_avg_sq"].clamp_min(eps * eps).pow(SOAP_DENOM_POWER)
    if denom_floor_ratio > 0:
        denom_floor = denom.float().square().mean().sqrt().mul(denom_floor_ratio).clamp_min(eps)
        denom = denom.clamp_min(denom_floor.to(denom.dtype))
    precond = q_row @ (projected / denom) @ q_col.T
    if blend != 1.0:
        precond = blend * precond + (1 - blend) * update_f
    precond.mul_(gram_frobenius_norm_estimate(update_f, eps=eps) / gram_frobenius_norm_estimate(precond, eps=eps))
    return precond.to(update.dtype)

def soap_update_preconditioner(grad, state, shampoo_beta=SOAP_BETA2, precondition_frequency=SOAP_PRECONDITION_FREQUENCY):
    grad_f = grad.float()
    state["row_gg"].lerp_(grad_f @ grad_f.T, 1 - shampoo_beta)
    state["col_gg"].lerp_(grad_f.T @ grad_f, 1 - shampoo_beta)
    if state["q_row"] is None:
        state["q_row"] = soap_eigenbasis(state["row_gg"])
        state["q_col"] = soap_eigenbasis(state["col_gg"])
    elif state["soap_step"] > 0 and state["soap_step"] % precondition_frequency == 0:
        state["q_row"], state["q_col"], state["exp_avg_sq"] = soap_basis_qr(
            state["row_gg"], state["col_gg"], state["q_row"], state["q_col"], state["exp_avg_sq"]
        )
    state["soap_step"] += 1

def _linear_ramp(step: int, start_step: int, end_step: int) -> float:
    if end_step <= start_step:
        return 1.0 if step >= end_step else 0.0
    return min(1.0, max(0.0, (step - start_step) / (end_step - start_step)))

def contra_coeff_for_step(step: int) -> float:
    contra_to_normal = _linear_ramp(step, CONTRA_HOLD_END_STEP, CONTRA_TO_NORMAL_END_STEP)
    return CONTRA_MUON_COEFF * (1.0 - contra_to_normal)

def soft_blend_for_step(step: int) -> float:
    return min(SOFT_MUON_CEIL, _linear_ramp(step, NORMAL_TO_SOFT_START_STEP, NORMAL_TO_SOFT_END_STEP))

def muon_update(update, second_moment, step, beta2=NOR_BETA2, use_contra=True, use_soft=True):
    normalized_grad = scale_to_unit_operator_norm(update.clone())
    ns_update = zeropower_via_newtonschulz5(update)
    update_norm_estimate = gram_frobenius_norm_estimate(ns_update)

    contra_coeff = contra_coeff_for_step(step) if use_contra else 0.0
    contra_update = ns_update + contra_coeff * normalized_grad
    contra_update = contra_update * update_norm_estimate / gram_frobenius_norm_estimate(contra_update)
    if use_soft:
        soft_update = soft_via_newtonschulz5(update, SOFT_MUON_P, SOFT_MUON_SCALE, SOFT_MUON_INPUT_NORM)
        soft_update = soft_update * update_norm_estimate / gram_frobenius_norm_estimate(soft_update)
        blend = soft_blend_for_step(step)
    else:
        soft_update = contra_update
        blend = 0.0
    update = contra_update + (soft_update - contra_update) * blend
    update = update * update_norm_estimate / gram_frobenius_norm_estimate(update)
    update *= max(1, update.size(-2) / update.size(-1))**0.5
    # Per-row variance (or per-col if matrix is wide). Keep along the longer dim.
    if update.size(-2) >= update.size(-1):
        per_row_var = (update * update).mean(dim=-1, keepdim=True)  # shape (..., m, 1)
    else:
        per_row_var = (update * update).mean(dim=-2, keepdim=True)  # shape (..., 1, n)
    second_moment.lerp_(per_row_var.float(), 1 - beta2)
    vnorm = gram_frobenius_norm_estimate(update)
    update = update * second_moment.clamp_min(1e-10).rsqrt().to(update.dtype)
    vnorm_new = gram_frobenius_norm_estimate(update)
    update = update * (vnorm / vnorm_new)
    return update

class Muon(torch.optim.Optimizer):
    def __init__(self, named_params, lr=0.02, weight_decay=0, mu=0.95):
        assert isinstance(named_params, list) and len(named_params) >= 1
        self.soap_params = {p for n, p in named_params if should_soap_param(n)}
        self.attn_soap_params = {p for n, p in named_params if should_soap_param(n) and is_attn_param(n)}
        self.attn_proj_soap_params = {p for n, p in named_params if should_soap_param(n) and is_attn_proj_param(n)}
        self.v_params = {p for n, p in named_params if is_v_param(n)}
        self.no_contra_params = {p for n, p in named_params if param_matches_spec(n, NO_CONTRA_PARAM)}
        self.no_soft_params = {p for n, p in named_params if param_matches_spec(n, NO_SOFTMUON_PARAM)}
        self.step_count = 0
        params = sorted([p for _, p in named_params], key=lambda x: x.size(), reverse=True)
        defaults = dict(lr=lr, weight_decay=weight_decay, mu=mu)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self):
        world_size = dist.get_world_size()
        rank = dist.get_rank()
        for group in self.param_groups:
            params = group["params"]
            params_pad = params + [torch.empty_like(params[-1])] * (world_size - len(params) % world_size)
            for base_i in range(0, len(params), world_size):
                if base_i + rank < len(params):
                    p = params[base_i + rank]
                    state = self.state[p]
                    if len(state) == 0:
                        state["momentum"] = torch.zeros_like(p)
                        if p in self.soap_params:
                            state["exp_avg_sq"] = torch.zeros_like(p, dtype=torch.float32)
                            state["row_gg"] = torch.zeros(p.size(0), p.size(0), dtype=torch.float32, device=p.device)
                            state["col_gg"] = torch.zeros(p.size(1), p.size(1), dtype=torch.float32, device=p.device)
                            state["q_row"] = None
                            state["q_col"] = None
                            state["soap_step"] = 0
                        # Second-moment buffer matches per-row-or-col shape.
                        if p.size(-2) >= p.size(-1):
                            state["second_moment"] = torch.zeros((*p.shape[:-1], 1),
                                dtype=torch.float32, device=p.device)
                        else:
                            state["second_moment"] = torch.zeros((*p.shape[:-2], 1, p.shape[-1]),
                                dtype=torch.float32, device=p.device)
                    grad = p.grad
                    state["momentum"].lerp_(grad, 1 - group["mu"])
                    momentum_update = grad.lerp(state["momentum"], group["mu"])
                    is_attn_soap = p in self.attn_soap_params
                    use_soap = p in self.soap_params
                    if use_soap and SOAP_UPDATE_BEFORE_USE:
                        soap_update_preconditioner(grad, state)
                    if use_soap:
                        if is_attn_soap:
                            soap_blend = V_SOAP_BLEND if p in self.v_params else ATTN_SOAP_BLEND
                            if p in self.v_params and V_SOAP_BLEND_RAMP_END_STEP > 0:
                                soap_blend *= _linear_ramp(self.step_count, 0, V_SOAP_BLEND_RAMP_END_STEP)
                            soap_update = soap_precondition_momentum(
                                momentum_update, state, blend=soap_blend,
                                denom_floor_ratio=ATTN_SOAP_DENOM_FLOOR
                            )
                            if p in self.attn_proj_soap_params:
                                gate = bounded_trust_gate(
                                    trust_gate(momentum_update, soap_update, grad),
                                    self.step_count
                                )
                            else:
                                gate = torch.ones((), dtype=torch.float32, device=p.device)
                            gate = gate * attention_soap_blend_for_step(self.step_count)
                            momentum_update = norm_preserving_blend(momentum_update, soap_update, gate)
                        else:
                            momentum_update = soap_precondition_momentum(momentum_update, state, blend=SOAP_BLEND)
                    update = muon_update(
                        momentum_update,
                        state["second_moment"],
                        self.step_count,
                        use_contra=p not in self.no_contra_params,
                        use_soft=p not in self.no_soft_params,
                    )
                    # u/w-floor. SOAP and non-SOAP params can use different floors.
                    p_fro = p.float().norm().clamp_min(1e-8)
                    u_fro = update.float().norm().clamp_min(1e-8)
                    cur_uw = u_fro / p_fro
                    target_uw = SOAP_TARGET_UW if use_soap else NONSOAP_TARGET_UW
                    scale = torch.where(cur_uw < target_uw, target_uw * p_fro / u_fro, torch.ones_like(p_fro))
                    update = update * scale.to(update.dtype)
                    # WD set to 0 — u/w target replaces wd's role (smaller updates as p grows).
                    p.add_(update, alpha=-group["lr"])
                    if use_soap and not SOAP_UPDATE_BEFORE_USE:
                        soap_update_preconditioner(grad, state)
                dist.all_gather(params_pad[base_i:base_i + world_size], params_pad[base_i + rank])
        self.step_count += 1


########################################
#                Setup                 #
########################################

# torchrun sets these env variables
device = torch.device("cuda", int(os.environ["LOCAL_RANK"]))
torch.cuda.set_device(device)
torch.manual_seed(SEED)
dist.init_process_group(backend="nccl", device_id=device)
dist.barrier()
# this code can be run equivalently with 1, 2, 4, or 8 gpus.
assert 8 % dist.get_world_size() == 0

# logging setup
if dist.get_rank() == 0:
    log_dir = LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)
    logfile = str(log_dir / f"{uuid.uuid4()}.txt")
    print(logfile, flush=True)
def print0(s, console=False, log=True):
    if dist.get_rank() == 0:
        if console:
            print(s, flush=True)
        if log:
            with open(logfile, "a") as f:
                print(s, file=f)

# we begin by logging this file itself
print0(code)
print0("="*100)
print0(f"Running PyTorch {torch.version.__version__} compiled for CUDA {torch.version.cuda}")
print0(f"Running on device_name={torch.cuda.get_device_name(device)} with world_size={dist.get_world_size()}")
print0(f"Using seed={SEED}")
print0(f"Experiment={EXPERIMENT_NAME}")
print0(f"Intuition={EXPERIMENT_INTUITION}")
print0("Muon update linearly changes from Contra Muon to normal Muon, then normal Muon to soft Muon.")
print0("This script retains the PR 274 NorMuon-lite row/column variance normalization and u/w-floor postprocessing.")
print0("MLP and V SOAP stay on all run; V SOAP blend is fixed at 0.95.")
print0(f"Schedule uses hardcoded PR 287 cooldown constants with train_steps={FINAL_TRAIN_STEPS}, schedule_steps={FINAL_SCHEDULE_STEPS}.")
print0(f"Using contra_muon_coeff={CONTRA_MUON_COEFF}")
print0(f"Using soft_muon_p={SOFT_MUON_P}")
print0(f"Using soft_muon_scale={SOFT_MUON_SCALE}")
print0(f"Using soft_muon_input_norm={SOFT_MUON_INPUT_NORM}")
print0(f"Using soft_muon_ceil={SOFT_MUON_CEIL}")
print0(f"Using contra_hold_end_step={CONTRA_HOLD_END_STEP}")
print0(f"Using contra_to_normal_end_step={CONTRA_TO_NORMAL_END_STEP}")
print0(f"Using normal_to_soft_start_step={NORMAL_TO_SOFT_START_STEP}")
print0(f"Using normal_to_soft_end_step={NORMAL_TO_SOFT_END_STEP}")
print0(f"Using mu={MU}")
print0(f"Using muon_lr={MUON_LR}")
print0(f"Using muon_weight_decay={MUON_WEIGHT_DECAY}")
print0(f"Using target_uw={TARGET_UW}")
print0(f"Using soap_target_uw={SOAP_TARGET_UW}")
print0(f"Using nonsoap_target_uw={NONSOAP_TARGET_UW}")
print0(f"Using nor_beta2={NOR_BETA2}")
print0(f"Using soap_beta2={SOAP_BETA2}")
print0(f"Using soap_precondition_frequency={SOAP_PRECONDITION_FREQUENCY}")
print0(f"Using soap_denom_power={SOAP_DENOM_POWER}")
print0(f"Using soap_blend={SOAP_BLEND}")
print0(f"Using soap_update_before_use={SOAP_UPDATE_BEFORE_USE}")
print0(f"Using soap_param_mode={SOAP_PARAM_MODE}")
print0(f"Using attn_soap_denom_floor={ATTN_SOAP_DENOM_FLOOR}")
print0(f"Using attn_soap_blend={ATTN_SOAP_BLEND}")
print0(f"Using v_soap_blend={V_SOAP_BLEND}")
print0(f"Using v_soap_blend_ramp_end_step={V_SOAP_BLEND_RAMP_END_STEP}")
print0(f"Using attn_early_trust_floor={ATTN_EARLY_TRUST_FLOOR}")
print0(f"Using attn_early_trust_cap={ATTN_EARLY_TRUST_CAP}")
print0(f"Using attn_trust_floor_end_step={ATTN_TRUST_FLOOR_END_STEP}")
print0(f"Using attn_trust_floor_fade_end_step={ATTN_TRUST_FLOOR_FADE_END_STEP}")
print0(f"Using attn_trust_min_agree={ATTN_TRUST_MIN_AGREE}")
print0(f"Using attn_trust_min_grad_align={ATTN_TRUST_MIN_GRAD_ALIGN}")
print0(f"Using attn_trust_power={ATTN_TRUST_POWER}")
print0(f"Using attn_soap_fade_start_step={ATTN_SOAP_FADE_START_STEP}")
print0(f"Using attn_soap_fade_end_step={ATTN_SOAP_FADE_END_STEP}")
print0(f"Using no_contra_param={NO_CONTRA_PARAM}")
print0(f"Using no_softmuon_param={NO_SOFTMUON_PARAM}")
print0(
    f"WR resume generated run checkpoint={WR_RESUME_CHECKPOINT or '<none>'} "
    f"model_checkpoint={WR_RESUME_MODEL_CHECKPOINT or '<none>'} "
    f"optimizer_checkpoint={WR_RESUME_OPTIMIZER_CHECKPOINT or '<none>'} "
    f"advance_data={WR_RESUME_ADVANCE_DATA} restore_rng={WR_RESUME_RESTORE_RNG} "
    f"load_adam={WR_RESUME_LOAD_ADAM} load_optimizers={WR_RESUME_LOAD_OPTIMIZERS} "
    f"save_checkpoint={WR_SAVE_CHECKPOINT or '<none>'}@{WR_SAVE_CHECKPOINT_STEP} "
    f"target_loss={WR_TARGET_LOSS}",
    console=True,
)
print0("="*100)

val_tokens = 20 * 524288
batch_size = 8 * 64 * 1024
mbs = 64
train_loader = distributed_data_generator("data/fineweb10B/fineweb_train_*.bin", batch_size)
val_inputs, val_targets = next(distributed_data_generator("data/fineweb10B/fineweb_val_*.bin", val_tokens))

model = GPT(vocab_size=50304, num_layers=12, model_dim=768).cuda()
model.compile(dynamic=False)


########################################
#       Init & Optim Hyperparams       #
########################################

# we want to minimize this while still reaching 3.28 val loss
train_steps = FINAL_TRAIN_STEPS
val_regular_interval = 125
extra_val_steps = {3000, 3010, 3020, 3030, 3040}

# initialize model parameters
for name, p in model.named_parameters():
    if "proj" in name:
        p.data.zero_()

# create the optimizer(s)
optimizer1 = AdamW([dict(params=[model.embed.weight], lr=0.3),
                    dict(params=[model.proj.weight], lr=1/320),
                    dict(params=[p for p in model.parameters() if p.ndim < 2], lr=0.01)],
                   betas=(0.8, 0.95), eps=1e-10, weight_decay=0, fused=True)
# Skylight-001: NorMuon-lite (per-row variance) + u/w-floor=0.35 + lr=0.0375 + wd=0.025.
optimizer2 = Muon([(n, p) for n, p in model.blocks.named_parameters() if p.ndim >= 2],
                  lr=MUON_LR, weight_decay=MUON_WEIGHT_DECAY, mu=MU)
optimizers = [optimizer1, optimizer2]
assert set(p for opt in optimizers for group in opt.param_groups
           for p in group["params"]) == set(model.parameters())
for opt in optimizers:
    for group in opt.param_groups:
        group["initial_lr"] = group["lr"]
optimizer1.param_groups[0]["power_c"] = ADAM_EMBED_POWER_C
optimizer1.param_groups[1]["power_c"] = ADAM_PROJ_POWER_C
optimizer1.param_groups[2]["power_c"] = ADAM_OTHER_POWER_C
optimizer2.param_groups[0]["power_c"] = MUON_POWER_C
start_step = maybe_load_wr_resume_checkpoint(model, optimizer1, optimizer2)
if start_step > 0 and WR_RESUME_ADVANCE_DATA:
    for _ in range(start_step):
        next(train_loader)
    print0(f"wr_resume_advanced_data steps:{start_step}", console=True)

# learning rate schedule: stable then decay
def _lr(step, initial_lr, power_c, power=1.0):
    t_end = FINAL_SCHEDULE_STEPS
    flat_lr = initial_lr
    downward_lr = power_c * max(0.0, t_end - step) ** power
    return min(flat_lr, downward_lr)

def set_hparams(step):
    progress = step / FINAL_SCHEDULE_STEPS
    assert 0 <= progress < 1
    for opt in optimizers:
        for group in opt.param_groups:
            group["lr"] = _lr(step, group["initial_lr"], group["power_c"], FINAL_LR_POWER)




########################################
#        Training and Validation       #
########################################

for p in model.parameters():
    dist.broadcast(p.detach(), 0)
# start the clock
training_time = 0
dist.barrier()
t0 = time.perf_counter()
for step in range(start_step, train_steps + 1):

    # --------------- VALIDATION SECTION -----------------
    should_validate = (
        step == train_steps
        or (step > 0 and step % val_regular_interval == 0)
        or step in extra_val_steps
    )
    if should_validate:
        # stop the clock
        dist.barrier()
        training_time += time.perf_counter() - t0
        model.eval()
        val_loss = 0
        with torch.no_grad():
            assert len(val_inputs) % mbs == 0
            for i in range(len(val_inputs) // mbs):
                val_loss += model(val_inputs[i*mbs:(i+1)*mbs], val_targets[i*mbs:(i+1)*mbs])
        dist.all_reduce(val_loss, op=dist.ReduceOp.SUM)
        val_loss /= val_tokens
        effective_steps = max(step - start_step, 1)
        print0(f"step:{step}/{train_steps} val_loss:{val_loss:.5f} train_time:{training_time:.3f}s"
               + f" step_avg:{1000*training_time/effective_steps:.2f}ms", console=True)
        maybe_save_wr_checkpoint(WR_SAVE_CHECKPOINT, step, model, optimizer1, optimizer2, val_loss=val_loss)
        if WR_TARGET_LOSS > 0 and float(val_loss) <= WR_TARGET_LOSS:
            print0(f"target_loss_reached step:{step} val_loss:{val_loss:.5f} target:{WR_TARGET_LOSS:.5f}", console=True)
            break
        model.train()
        # start the clock again
        dist.barrier()
        t0 = time.perf_counter()

    if step == train_steps:
        break

    # --------------- TRAINING SECTION -----------------
    inputs, targets = next(train_loader)
    # accumulate across microbatches in case we are running with fewer than 8 gpus
    assert len(inputs) % mbs == 0
    for i in range(len(inputs) // mbs):
        loss = model(inputs[i*mbs:(i+1)*mbs], targets[i*mbs:(i+1)*mbs])
        # NaN guard: catch divergence the step it happens, not 750 steps later.
        if not torch.isfinite(loss).all():
            raise RuntimeError(f"non-finite train loss at step {step} mb {i}: {loss.item()}")
        loss.backward()
    for name, p in model.named_parameters():
        assert p.grad is not None, name
        dist.all_reduce(p.grad, op=dist.ReduceOp.SUM)
    # set optimization hyperparameters and take a step
    set_hparams(step)
    for opt in optimizers:
        opt.step()
    model.zero_grad(set_to_none=True)
    if TRAIN_PROGRESS_INTERVAL > 0 and (step + 1) % TRAIN_PROGRESS_INTERVAL == 0:
        approx_training_time = training_time + (time.perf_counter() - t0)
        print0(f"step:{step+1}/{train_steps} train_time:{approx_training_time:.3f}s"
               + f" step_avg:{1000*approx_training_time/(step + 1):.2f}ms", console=True, log=False)

dist.destroy_process_group()
